# Bharat PDF 🇮🇳

Android PDF utility app.

Features:
- Scan to PDF
- Image to PDF
- Merge PDF
- Split PDF
- Lossless structural PDF re-save
- Password protection
- Open PDF

Build with GitHub Actions or Android Studio.
