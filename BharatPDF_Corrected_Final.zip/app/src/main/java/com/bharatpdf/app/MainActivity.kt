package com.bharatpdf.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> if (uris.isNotEmpty()) createPdfFromImages(uris) }

    private val mergePicker = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> if (uris.size >= 2) mergePdfs(uris) else if (uris.isNotEmpty()) toast("Select at least 2 PDFs") }

    private val splitPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { splitPdf(it) } }

    private val compressPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { compressPdf(it) } }

    private val lockPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { showPasswordDialog(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)

        findViewById<Button>(R.id.scanButton).setOnClickListener { startScanner() }
        findViewById<Button>(R.id.imagePdfButton).setOnClickListener { imagePicker.launch("image/*") }
        findViewById<Button>(R.id.mergeButton).setOnClickListener { mergePicker.launch("application/pdf") }
        findViewById<Button>(R.id.splitButton).setOnClickListener { splitPicker.launch("application/pdf") }
        findViewById<Button>(R.id.compressButton).setOnClickListener { compressPicker.launch("application/pdf") }
        findViewById<Button>(R.id.lockButton).setOnClickListener { lockPicker.launch("application/pdf") }
        findViewById<Button>(R.id.myPdfsButton).setOnClickListener { openPdf() }
    }

    private fun startScanner() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(20)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .build()

        GmsDocumentScanning.getClient(options).getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                try {
                    startIntentSenderForResult(sender, 1001, null, 0, 0, 0, null)
                } catch (_: Exception) {
                    toast("Scanner start failed")
                }
            }
            .addOnFailureListener { toast("Document scanner is not available") }
    }

    @Deprecated("Legacy activity result used for ML Kit scanner compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == Activity.RESULT_OK && data != null) {
            GmsDocumentScanningResult.fromActivityResultIntent(data)
                ?.pdf?.uri?.let { saveUri(it, "Scan") }
        }
    }

    private fun saveUri(uri: Uri, prefix: String) {
        try {
            val file = outputFile("${prefix}_${System.currentTimeMillis()}.pdf")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            status.text = "Saved: ${file.name}"
            toast("PDF saved")
        } catch (_: Exception) {
            toast("Could not save PDF")
        }
    }

    private fun createPdfFromImages(uris: List<Uri>) {
        val file = outputFile("Images_${System.currentTimeMillis()}.pdf")
        val doc = android.graphics.pdf.PdfDocument()
        try {
            uris.forEachIndexed { i, uri ->
                val bmp = contentResolver.openInputStream(uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it)
                } ?: return@forEachIndexed

                val width = bmp.width.coerceAtLeast(1)
                val height = bmp.height.coerceAtLeast(1)
                val info = android.graphics.pdf.PdfDocument.PageInfo.Builder(width, height, i + 1).create()
                val page = doc.startPage(info)
                page.canvas.drawBitmap(bmp, 0f, 0f, null)
                doc.finishPage(page)
                bmp.recycle()
            }
            FileOutputStream(file).use { doc.writeTo(it) }
            status.text = "Saved: ${file.name}"
            toast("PDF created")
        } catch (_: Exception) {
            toast("Could not create PDF")
        } finally {
            doc.close()
        }
    }

    private fun mergePdfs(uris: List<Uri>) {
        val file = outputFile("Merged_${System.currentTimeMillis()}.pdf")
        try {
            val merger = PDFMergerUtility()
            merger.destinationFileName = file.absolutePath
            uris.forEach { uri ->
                contentResolver.openInputStream(uri)?.let { merger.addSource(it) }
            }
            merger.mergeDocuments(null)
            status.text = "Saved: ${file.name}"
            toast("PDFs merged")
        } catch (_: Exception) {
            toast("Could not merge PDFs")
        }
    }

    private fun splitPdf(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { source ->
                val document = PDDocument.load(source)
                val pages = document.numberOfPages
                for (i in 0 until pages) {
                    val one = PDDocument()
                    one.addPage(document.getPage(i))
                    val file = outputFile("Split_${System.currentTimeMillis()}_${i + 1}.pdf")
                    one.save(file)
                    one.close()
                }
                document.close()
                status.text = "Split $pages pages"
                toast("PDF split into $pages files")
            }
        } catch (_: Exception) {
            toast("Could not split PDF")
        }
    }

    private fun compressPdf(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { source ->
                val doc = PDDocument.load(source)
                val file = outputFile("Compressed_${System.currentTimeMillis()}.pdf")
                doc.save(file)
                doc.close()
                status.text = "Saved: ${file.name}"
                toast("Compressed PDF saved")
            }
        } catch (_: Exception) {
            toast("Could not compress PDF")
        }
    }

    private fun showPasswordDialog(uri: Uri) {
        val input = EditText(this)
        input.hint = "Password (min 4 characters)"
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        AlertDialog.Builder(this)
            .setTitle("Lock PDF")
            .setMessage("Set a password for this PDF.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Lock") { _, _ ->
                val password = input.text.toString()
                if (password.length < 4) toast("Use at least 4 characters")
                else lockPdf(uri, password)
            }
            .show()
    }

    private fun lockPdf(uri: Uri, password: String) {
        try {
            contentResolver.openInputStream(uri)?.use { source ->
                val doc = PDDocument.load(source)
                val permissions = AccessPermission()
                val policy = StandardProtectionPolicy(password, password, permissions)
                policy.encryptionKeyLength = 128
                doc.protect(policy)
                val file = outputFile("Locked_${System.currentTimeMillis()}.pdf")
                doc.save(file)
                doc.close()
                status.text = "Saved: ${file.name}"
                toast("Password protected PDF saved")
            }
        } catch (_: Exception) {
            toast("Could not lock PDF")
        }
    }

    private fun openPdf() {
        startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/pdf"
            addCategory(Intent.CATEGORY_OPENABLE)
        })
    }

    private fun outputDir(): File {
        val dir = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "BharatPDF")
        dir.mkdirs()
        return dir
    }

    private fun outputFile(name: String): File = File(outputDir(), name)

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
